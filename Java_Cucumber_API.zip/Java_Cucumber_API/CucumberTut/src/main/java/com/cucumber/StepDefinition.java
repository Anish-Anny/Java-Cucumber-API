package com.cucumber;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.annotation.en.And;
import cucumber.annotation.en.Given;
import cucumber.annotation.en.Then;
import cucumber.annotation.en.When;
import junit.framework.Assert;

public class StepDefinition {

	WebDriver driver;
	
	@Given("^I am on login page$")
	public void i_am_on_login_page() throws Throwable {
		System.out.println("open login page url");
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\kk5051934\\Desktop\\aLL SOGT\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:///C:/Users/kk5051934/Desktop/loginpage.html");
	}

	@Given("^I open login page$")
	public void I_open_login_page()  throws Throwable {
		System.out.println("open login page url");
		
		String title = driver.getTitle();
		System.out.println(title);
		Assert.assertEquals("Cucumber Test", title);
	
	}
	
	@When("^I enter name as \"([^\"]*)\"$")
	public void I_enter_name_as(String arg1) throws Throwable {
		System.out.println("Enter user name");
		
		driver.findElement(By.name("uname")).sendKeys("jsmith");
	
	}

	@And("^passward \"([^\"]*)\"$")
	public void passward(String arg1) throws Throwable {
		System.out.println("Enter user Password");
		driver.findElement(By.name("psw")).sendKeys("demo123");
		
	}

	@When("^I submit login page$")
	public void submit_login_page()throws Throwable {
		System.out.println("submit login page");
		 
        WebElement loginBtn = driver.findElement(By.xpath("//input[@type='submit']"));
       JavascriptExecutor js =  (JavascriptExecutor) driver;
       js.executeScript("arguments[0].click();", loginBtn);

	//	Assert.assertEquals("jsmith", "jsmith");
		Assert.assertEquals("demo123", "demo123");
	}
	@Then("^I redirect to user login page$")
	public void I_redirect_to_user_login_page()  throws Throwable {
		System.out.println("Verfiy: current page is user home page");
		
	}

	
		
	}


