package com.cucumber;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.junit.Cucumber;
//import cucumber.junit.Cucumber.Options;

@RunWith(Cucumber.class)
@CucumberOptions(features="classpath:/LoginTest.feature" , glue="com.cucumber")

@Cucumber.Options(format = {"html:target/cucumber-reports", "json:target/Cucumber.json","junit:target/Cucumber.xml" })
public class TestRunner {

}
